<strong> **DO NOT DISTRIBUTE OR PUBLICLY POST SOLUTIONS TO THESE LABS. MAKE ALL FORKS OF THIS REPOSITORY WITH SOLUTION CODE PRIVATE. PLEASE REFER TO THE STUDENT CODE OF CONDUCT AND ETHICAL EXPECTATIONS FOR COLLEGE OF INFORMATION TECHNOLOGY STUDENTS FOR SPECIFICS. ** </strong>

# WESTERN GOVERNORS UNIVERSITY
### Israel Osorio
### Student ID: 012049937

## D683 – ADVANCED AI AND ML

# Music & Mental Health Prediction Model

## Overview
This AI/ML model analyzes music listening patterns to predict potential mental health indicators like Anxiety, Depression, OCD, and Insomnia. The solution is trained using a Random Forest Classifier and evaluated using cross-validation and hyperparameter tuning.

## 1. Requirements

### Software
- **Python 3.8+**
- **Git**
- **VS Code** or any IDE with Python support

### Python Libraries

- pandas
- numpy
- scikit-learn

### Hardware
- Minimum: 8GB RAM, 2-core CPU
- Recommended: 16GB RAM for faster processing of GridSearchCV

------

## 2. Instructions to Run the AI/ML Application

### Setup

1. Clone the repository from GitLab:
   ```bash
   git clone <your-gitlab-repo-url>
   cd <repo-folder>

2. Run the script 'python algorithm.py'



#Israel Osorio
#Student ID: 012049937

import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
from sklearn.model_selection import cross_val_score

df = pd.read_csv("Preprocessed_Data.csv", sep=',')

df = df.drop(columns=['Unnamed: 0', 'Timestamp'])

conditions = ['Anxiety', 'Depression', 'OCD', 'Insomnia']

for condition in conditions:

    print("\n" + condition + "\n" )

    df[f'{condition}_High'] = np.where(df[condition] >= 5, 1, 0)

    X = df.drop(columns=conditions + [f'{condition}_High'])  # drop all raw scores
    y = df[f'{condition}_High']

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Model
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)

    print(classification_report(y_test, y_pred))


####Cross Validation####

    cv_scores = cross_val_score(model, X, y, cv=5, scoring='accuracy')
    print(f"Cross-validation scores: {cv_scores}")
    print(f"Mean accuracy: {cv_scores.mean():.2f}")


####Hyperparameter Tuning####

    from sklearn.model_selection import GridSearchCV

    param_grid = {
            'n_estimators': [50, 100, 150],
            'max_depth': [5, 10, None],
            'min_samples_split': [2, 5, 10]
        }

    grid_search = GridSearchCV(RandomForestClassifier(random_state=42),
                                param_grid,
                                cv=5,
                                scoring='accuracy',
                                n_jobs=-1)

    grid_search.fit(X_train, y_train)

    print(f"Best parameters for {condition}: {grid_search.best_params_}")
    print(f"Best Grid-Search score: {grid_search.best_score_:.2f}")

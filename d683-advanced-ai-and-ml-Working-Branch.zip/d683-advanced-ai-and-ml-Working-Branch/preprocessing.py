import sklearn
import pandas as pd 
import numpy as np
from sklearn.preprocessing import OrdinalEncoder
from sklearn.impute import SimpleImputer

df = pd.read_csv("mxmh_survey_results.csv", sep=',')

#Apply Ordinal Encoding to the columsn that are categorically based
cate_cols = df.select_dtypes(include=['object']).columns
encoder = OrdinalEncoder()
df[cate_cols] = encoder.fit_transform(df[cate_cols])


numeric_cols = df.select_dtypes(include=['float64', 'int64']).columns
df_numeric = df[numeric_cols]

# Apply mean imputation
imp_mean = SimpleImputer(strategy='mean')
df_imputed = pd.DataFrame(imp_mean.fit_transform(df_numeric), columns=numeric_cols)

df[numeric_cols] = df_imputed

#Test to make sure its preprocessing the correct columns
#print(df.head())

df.to_csv("Preprocessed_Data.csv")